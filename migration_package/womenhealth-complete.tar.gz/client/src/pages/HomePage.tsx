import Hero from "@/components/Hero";

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Hero />
    </div>
  );
}