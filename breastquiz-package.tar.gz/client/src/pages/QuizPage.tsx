import Quiz from "../components/Quiz";

export default function QuizPage() {
  return <Quiz />;
}